import os
from PIL import Image
from flask import current_app
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_boutique_image(image_file, boutique_id):
    if not image_file or not allowed_file(image_file.filename):
        return None
        
    filename = secure_filename(f"boutique_{boutique_id}_{image_file.filename}")
    filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    
    # Redimensionner et sauvegarder l'image
    img = Image.open(image_file)
    img.thumbnail((800, 800))  # Taille max
    img.save(filepath)
    
    return filename 